package service.ownday.spring.model.service;

public interface ChatService {
}
