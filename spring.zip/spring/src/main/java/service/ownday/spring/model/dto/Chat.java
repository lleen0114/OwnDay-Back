package service.ownday.spring.model.dto;

public class Chat {
}
