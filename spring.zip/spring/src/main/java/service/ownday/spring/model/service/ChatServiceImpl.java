package service.ownday.spring.model.service;

import org.springframework.stereotype.Service;

@Service
public class ChatServiceImpl implements  ChatService{
}
