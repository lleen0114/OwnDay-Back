package service.ownday.spring.model.service;

import org.springframework.stereotype.Service;

@Service
public class CalendarServiceImpl implements  CalendarService{
}
